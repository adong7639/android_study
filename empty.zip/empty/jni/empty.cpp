#include <jni.h>
#include <android/log.h>
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, "keymatch", __VA_ARGS__)
#include <string>
using namespace std;

extern "C"
jstring Java_com_example_empty_MainActivity_stringTestNdk(JNIEnv *env, jobject thiz)
{
	LOGD("###HERE");
	string filePath = "hello jni";
	jstring jfilePath=env->NewStringUTF(filePath.c_str());
	return jfilePath;
	//return env->NewStringUTF("Hello Test NDK !");
}
