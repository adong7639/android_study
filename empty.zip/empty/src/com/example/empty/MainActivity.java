package com.example.empty;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.example.empty.R;

import android.R.integer;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

//private static final String TAG = "maddock";
//Log.e(TAG,"This is the error log print edby Log.iinandroiduserspace."); 

public class MainActivity extends Activity {

	private static final String ACTIVITY_TAG="MainActivity";
	private List<String> lstFile =new ArrayList<String>(); //��� List
	
    private Button btn1;  
    ArrayList<Integer>MultiChoiceID = new ArrayList<Integer>(); 
  //���ÿؼ���ʾ���е�txt�ļ��б�
	private String strtest="file0";
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView  myTextView =  (TextView)findViewById(R.id.tv1);
        myTextView.setText("kaishi");
        //setContentView(myTextView); //��������ʾ
        String strviewndk = stringTestNdk();
        myTextView.setText(strviewndk);
        
        System.out.println("sss");
        //LOG��ʹ�÷���
        //tag:MainActivity show tag
//        int k = 563;
//        Log.v(MainActivity.ACTIVITY_TAG, "This is Verbose k=" + k);
//        Log.d(MainActivity.ACTIVITY_TAG, "This is Debug.");
//        Log.i(MainActivity.ACTIVITY_TAG, "This is Information");
//        Log.w(MainActivity.ACTIVITY_TAG, "This is Warnning.");
//        Log.e(MainActivity.ACTIVITY_TAG, "This is Error.");
        
        //�����ļ����е��ļ�
        String Path = "sdcard/360";
        String Extension = ".txt";
        boolean IsIterative = false;
        GetFiles(Path,Extension,IsIterative);
        Log.v(MainActivity.ACTIVITY_TAG, "lisfilesize="+ lstFile.size());
        for (int i = 0; i <lstFile.size(); i++) {
        	//Log.v(MainActivity.ACTIVITY_TAG, lstFile.get(i));
		}
        

        
        //final String [] nItems = {"item1","item2","item3","item4","item5","item6"};
        final String[] nItems = new String[lstFile.size()];
        for (int i = 0; i < lstFile.size(); i++) {
        	nItems[i] = lstFile.get(i);
		}
        
        
        
        btn1 = (Button) findViewById(R.id.mulchose);  
        btn1.setOnClickListener(new OnClickListener() {  
              
            @Override  
            public void onClick(View v) {  
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);  
                  
                MultiChoiceID.clear();  
                builder.setIcon(R.drawable.ic_launcher);  
                builder.setTitle("����ѡ��");  
                //  ���ö�ѡ��  
                builder.setMultiChoiceItems(nItems,   
                        new boolean[]{false,false,false,false,false,false},  
                        new DialogInterface.OnMultiChoiceClickListener() {  
                      
                            @Override  
                            public void onClick(DialogInterface arg0, int arg1, boolean arg2) {  
                                // TODO Auto-generated method stub  
                                if (arg2) {  
                                    MultiChoiceID.add(arg1);  
                                    String tip = "��ѡ���IDΪ"+arg1+",ֵΪ"+nItems[arg1];  
                                    Toast toast = Toast.makeText(getApplicationContext(), tip, Toast.LENGTH_SHORT);  
                                    toast.show();  
                                }  
                                else {  
                                    MultiChoiceID.remove(arg1);  
                                }  
                            }  
                });  
                //  ����ȷ����ť  
                builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {  
                      
                    @Override  
                    public void onClick(DialogInterface arg0, int arg1) {  
                        // TODO Auto-generated method stub  
                        String str = "";  
                        int size = MultiChoiceID.size();  
                        for(int i = 0; i < size; i++) {  
                            str += (nItems[MultiChoiceID.get(i)]+",");  
                        }  
                        Toast toast = Toast.makeText(getApplicationContext(), "��ѡ����"+str, Toast.LENGTH_LONG);  
                        toast.show();  
                        strtest = str;
                        Log.v(MainActivity.ACTIVITY_TAG, strtest);
                    }  
                });  
                //  ����ȡ����ť  
                builder.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {  
                      
                    @Override  
                    public void onClick(DialogInterface arg0, int arg1) {  
                        // TODO Auto-generated method stub  
                          
                    }  
                });  
                  
                builder.create().show();  
            }             
        }); 
        
        
    }
    
    public native String  stringTestNdk();   
    static {  
        System.loadLibrary("empty");  
    }  
    
	 
	public void GetFiles(String Path, String Extension, boolean IsIterative) //����Ŀ¼����չ�����Ƿ�������ļ���
	{
	    File[] files =new File(Path).listFiles();
	 
	    for (int i =0; i < files.length; i++)
	    {
	        File f = files[i];
	        if (f.isFile())
	        {
	            if (f.getPath().substring(f.getPath().length() - Extension.length()).equals(Extension)) //�ж���չ��
	                lstFile.add(f.getPath());
	 
	            if (!IsIterative)
	            {
	            	
	            }
	                //break;
	        }
	        else if (f.isDirectory() && f.getPath().indexOf("/.") == -1) //���Ե��ļ��������ļ�/�ļ��У�
	            GetFiles(f.getPath(), Extension, IsIterative);
	    }
	}
	
}
